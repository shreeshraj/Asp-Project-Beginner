﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class registration : System.Web.UI.Page
{
    SqlConnection sqlconnection;
    string connection = ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected string GetIPAddress()
    {
        System.Web.HttpContext context = System.Web.HttpContext.Current;
        string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

        if (!string.IsNullOrEmpty(ipAddress))
        {
            string[] addresses = ipAddress.Split(',');
            if (addresses.Length != 0)
            {
                return addresses[0];
            }
        }

        return context.Request.ServerVariables["REMOTE_ADDR"];
    }
    protected void btnregistration_Click(object sender, EventArgs e)
    {
       try
       { 
     sqlconnection = new SqlConnection(connection);

     SqlCommand sqlcommand1 = new SqlCommand("spUserNameexist", sqlconnection);
     sqlcommand1.CommandType = CommandType.StoredProcedure;
     sqlcommand1.Parameters.AddWithValue("@Mobile",txtregmobile.Text);
     sqlconnection.Open();
    int MobileNumberCount =(int)sqlcommand1.ExecuteScalar();
               if (MobileNumberCount > 0)
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = " User Already Exist";
                    


                }
                else
                 {
        SqlCommand sqlcommand = new SqlCommand("sp_UserRegistration", sqlconnection);
        sqlcommand.CommandType = CommandType.StoredProcedure;
        sqlcommand.Parameters.AddWithValue("@Firstname", txtregfirstname.Text);
        sqlcommand.Parameters.AddWithValue("@LastName", txtreglastname.Text);
        sqlcommand.Parameters.AddWithValue("@Email", txtregemail.Text);
        sqlcommand.Parameters.AddWithValue("@Password", txtregpassword.Text);
        sqlcommand.Parameters.AddWithValue("@Mobile", txtregmobile.Text);
        sqlcommand.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
        sqlcommand.Parameters.AddWithValue("@ModifiedDate", DateTime.Now);
        sqlcommand.Parameters.AddWithValue("@IsActive", false);
        sqlcommand.Parameters.AddWithValue("@UserIp", GetIPAddress());
        sqlcommand.ExecuteNonQuery();
        lblMessage.ForeColor = System.Drawing.Color.Green;
        lblMessage.Text = "User Successfully Registred...";
                 }
           }
       catch
       {
           Response.Write("Something Is wrong with you");

       }
        finally
       {
           sqlconnection.Close();
       }
    }
       
        
       

}
