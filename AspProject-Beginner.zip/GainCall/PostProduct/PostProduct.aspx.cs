﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class PostProduct : System.Web.UI.Page
{
  
    string connectionstring = ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;
   
    SqlConnection sqlconnection;
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.FindControl("btnpost").Visible = false;
        sqlconnection= new SqlConnection(connectionstring);
        if (Session["UserSession"] == null)
        {

            Response.Redirect("..//login.aspx");
        }
        
        if (!IsPostBack)
        {
            ddlState.DataSource = Getdata("sp_getstate", null);
            ddlState.DataBind();
            ListItem liststate = new ListItem("--Select State--", "-1");
            ddlState.Items.Insert(0, liststate);
            ListItem listcity = new ListItem("--Select City--", "-1");
            ddlCity.Items.Insert(0, listcity);
            // ddlCity.Enabled = false;
        }
        
        
        
        
    }
    public DataSet Getdata(string spname, SqlParameter spparameter)
    {
        SqlDataAdapter sqladapter = new SqlDataAdapter(spname, sqlconnection);
        sqladapter.SelectCommand.CommandType = CommandType.StoredProcedure;
        if (spparameter != null)
        {

            sqladapter.SelectCommand.Parameters.Add(spparameter);
        }
        DataSet ds = new DataSet();
        sqladapter.Fill(ds);
        return ds;


    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
     string fileName = Guid.NewGuid().ToString(); 
     string extension = Path.GetExtension(FileUpload1.PostedFile.FileName); 
     FileUpload1.SaveAs(Server.MapPath("~//Image/"+fileName+extension));
     fileName="Image/"+fileName+extension;
     SqlCommand sqlcommand = new SqlCommand("sp_PostItem", sqlconnection);
     sqlcommand.CommandType = CommandType.StoredProcedure;
     sqlcommand.Parameters.AddWithValue("@ProductType",ddlType.SelectedItem.Text);
     sqlcommand.Parameters.AddWithValue("@UserId",int.Parse(Session["UserSession"].ToString()));
     sqlcommand.Parameters.AddWithValue("@ProductTitle",txttitle.Text);
     sqlcommand.Parameters.AddWithValue("@ProductDes",txtdescription.Text);
     sqlcommand.Parameters.AddWithValue("@ImgPath", fileName);
     sqlcommand.Parameters.AddWithValue("@State",ddlState.SelectedItem.Text);
     sqlcommand.Parameters.AddWithValue("@City",ddlCity.SelectedItem.Text);
     sqlcommand.Parameters.AddWithValue("@LostDate",txtDate.Text);
     sqlcommand.Parameters.AddWithValue("@Reward",txtreward.Text);
     sqlcommand.Parameters.AddWithValue("@Name",txtname.Text);
     sqlcommand.Parameters.AddWithValue("@Email",txtuseremail.Text);
     sqlcommand.Parameters.AddWithValue("@Mobile",txtmobile.Text);
     sqlcommand.Parameters.AddWithValue("@Isvarified",false);
     sqlcommand.Parameters.AddWithValue("@IsActive",false);
     sqlcommand.Parameters.AddWithValue("@Postedby", Session["FirstName"].ToString());
     sqlcommand.Parameters.AddWithValue("@PostedDate",DateTime.Now);
     sqlcommand.Parameters.AddWithValue("@ModifiedDate",DateTime.Now);
     sqlconnection.Open();
     sqlcommand.ExecuteNonQuery();
     sqlconnection.Close();

      
    }
   
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlState.SelectedValue == "-1")
        {
            ddlCity.SelectedIndex = 0;
            ddlCity.Enabled = false;

            //ddlCity.Enabled = false;
        }
        else
        {
            ddlCity.Enabled = true;
            SqlParameter newparameter = new SqlParameter("@stateid", ddlState.SelectedValue);
            ddlCity.DataSource = Getdata("sp_getcitybystateid", newparameter);
            ddlCity.DataBind();
        }  
    }
}