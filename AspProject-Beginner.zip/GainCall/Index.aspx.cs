﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Index : System.Web.UI.Page
{
    SqlConnection sqlconnection;
    string connectionstring;
    
    protected void Page_Load(object sender, EventArgs e)
    {
     
       connectionstring= ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;

       sqlconnection = new SqlConnection(connectionstring);
       if (!IsPostBack)
       {
           SqlCommand  countLostcommand = new SqlCommand ("Select  count(*) from ProductDetails where Product_Type='Lost Product'", sqlconnection);
           SqlCommand countFoundcommand = new SqlCommand("Select  count(*) from ProductDetails where Product_Type='Found Product'", sqlconnection);

           sqlconnection.Open();
           lblLostitems.Text=countLostcommand.ExecuteScalar().ToString();
           lblFounditems.Text = countFoundcommand.ExecuteScalar().ToString();
           sqlconnection.Close();

           SqlDataAdapter comm = new     SqlDataAdapter("Select TOP 4 ImagePath,Product_Id,Product_Title=SUBSTRING(Product_Title,1,50),Product_Description=SUBSTRING (Product_Description,1,150),PostedDate,Postedby  from ProductDetails  where Product_Type='Lost Product'", sqlconnection);
           SqlDataAdapter Foundcomm = new SqlDataAdapter("Select TOP 4 ImagePath,Product_Id,Product_Title=SUBSTRING(Product_Title,1,50),Product_Description=SUBSTRING (Product_Description,1,150),PostedDate,Postedby  from ProductDetails where Product_Type='Found Product'", sqlconnection);
          DataSet ds = new DataSet();
          DataSet ds1 = new DataSet();
          comm.Fill(ds);
          Foundcomm.Fill(ds1);
          
          Repeater1.DataSource = ds;
          Repeater2.DataSource = ds1;
          Repeater2.DataBind();
          Repeater1.DataBind();


           ddlState.DataSource = Getdata("sp_getstate", null);
           ddlState.DataBind();
           ListItem liststate = new ListItem("--Select State--", "-1");
           ddlState.Items.Insert(0, liststate);
           ListItem listcity = new ListItem("--Select City--", "-1");
           ddlCity.Items.Insert(0, listcity);
          // ddlCity.Enabled = false;
       }
       

    }

    protected void btnpost_Click(object sender, EventArgs e)
    {
       Response.Redirect("PostProduct/PostProduct.aspx");
    }
    public DataSet Getdata(string spname, SqlParameter spparameter)
    {
        using (SqlDataAdapter sqladapter = new SqlDataAdapter(spname, sqlconnection))
        {
            sqladapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            if (spparameter != null)
            {

                sqladapter.SelectCommand.Parameters.Add(spparameter);
            }
            DataSet ds = new DataSet();
            sqladapter.Fill(ds);
            return ds;

        }
    }
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        if(ddlState.SelectedValue=="-1")
        {
            ddlCity.SelectedIndex = 0;
            ddlCity.Enabled = false;

            //ddlCity.Enabled = false;
        }
        else

        {
          ddlCity.Enabled=true;
          SqlParameter newparameter=new SqlParameter("@stateid",ddlState.SelectedValue);
          ddlCity.DataSource = Getdata("sp_getcitybystateid", newparameter);
          ddlCity.DataBind();
        }
    }


    protected void btnsearch_Click(object sender, EventArgs e)
    {
        
       


        if(ddlProductType.SelectedItem.Text=="Lost Product")
        {


            Response.Redirect("ProductDetails/lost-product-details.aspx?State=" + Server.UrlEncode(ddlState.SelectedItem.Text) + "&City=" + Server.UrlEncode(ddlCity.SelectedItem.Text )+ "&ProductType=" + ddlProductType.SelectedItem.Text + "&Searchproduct=" + txtsearch.Text);
        }
        if(ddlProductType.SelectedItem.Text=="Found Product")
        {
            Response.Redirect("ProductDetails/found-product-details.aspx?State=" + ddlState.SelectedItem.Text + "&City=" + ddlCity.SelectedItem.Text + "&ProductType=" + ddlProductType.SelectedItem.Text + "&Searchproduct=" + txtsearch.Text);
            
        }







    }
}