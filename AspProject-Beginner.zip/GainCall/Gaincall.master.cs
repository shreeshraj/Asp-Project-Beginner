﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Gaincall : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserSession"] == null && Session["FirstName"]==null)
        {
            myDiv.Visible = false;
        }
        if (Session["UserSession"] != null && Session["FirstName"] != null)
        {
            myDiv.Visible = true;
            LoginBar.Visible = false;
            lblUsername.Text = Session["FirstName"].ToString();
        }

    }
    protected void btnpost_Click(object sender, EventArgs e)
    {
        if (Session["UserSession"] == null && Session["FirstName"] == null)
        {

            Response.Redirect("login.aspx");
        }
       else
        {
            Response.Redirect("~/PostProduct/PostProduct.aspx");
        }
    }
}
