﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class UserProfile : System.Web.UI.Page
   {
   string connectionstring;
   SqlConnection sqlconnection;
    
    protected void Page_Load(object sender, EventArgs e)
    {
      
       connectionstring= ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;

       sqlconnection = new SqlConnection(connectionstring);
       if (!IsPostBack)
       {
           if (Session["UserSession"] == null)
           {
               Response.Redirect("..//login.aspx");
           }
           else
           {
               int sessionid = int.Parse(Session["UserSession"].ToString());

               SqlCommand comm = new SqlCommand("select * from UserRegistration where UserId='" + sessionid + "'", sqlconnection);
               sqlconnection.Open();
               SqlDataReader dr = comm.ExecuteReader();
               while (dr.Read())
               {
                   txtFirstName.Text = dr[1].ToString();
                   txtLastName.Text = dr[2].ToString();
                   txtEmail.Text = dr[3].ToString();
                   txtMobile.Text = dr[5].ToString();
                   txtAddress.Text = dr[8].ToString();
                   txtPin.Text = dr[12].ToString();



               }
               sqlconnection.Close();

           }
       }

    }
    protected void btbUpdate_Click(object sender, EventArgs e)
    {
        int sessionid = int.Parse(Session["UserSession"].ToString());
        SqlCommand comm1 = new SqlCommand("sp_userupdate", sqlconnection);
       
        comm1.CommandType = CommandType.StoredProcedure;
        comm1.Parameters.AddWithValue("@Firstname",txtFirstName.Text);
        comm1.Parameters.AddWithValue("@LastName", txtLastName.Text);
        comm1.Parameters.AddWithValue("@dob", txtDob.Text);
        comm1.Parameters.AddWithValue("@gender", DropDownList1.SelectedItem.Text);
        comm1.Parameters.AddWithValue("@address",txtAddress.Text);
        comm1.Parameters.AddWithValue("@country", ddlCountry.SelectedItem.Text);
        comm1.Parameters.AddWithValue("@sate", ddlState.SelectedItem.Text);
        comm1.Parameters.AddWithValue("@city", ddlCity.SelectedItem.Text);
        comm1.Parameters.AddWithValue("@pin", txtPin.Text);
        comm1.Parameters.AddWithValue("@sessionid", sessionid);
        sqlconnection.Open();
        int count = comm1.ExecuteNonQuery();
        if (count == 1)
        {
            Response.Write("success");
        }
        else
        {
            Response.Write("fail");
        }
        sqlconnection.Close();
    }
}