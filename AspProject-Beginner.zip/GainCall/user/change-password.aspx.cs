﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class user_change_password : System.Web.UI.Page
{
    string connectionstring = ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;
   SqlConnection sqlconnection;  
    protected void Page_Load(object sender, EventArgs e)
    {
        sqlconnection = new SqlConnection(connectionstring);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand comm = new SqlCommand("sp_passwordupdate", sqlconnection);
        comm.CommandType = CommandType.StoredProcedure;
        comm.Parameters.AddWithValue("@Oldpassword",txtoldpassword.Text);
        comm.Parameters.AddWithValue("@Newpassword", txtnewpassword.Text);
        comm.Parameters.AddWithValue("@userid", Session["UserSession"].ToString());
        sqlconnection.Open();
        int count= comm.ExecuteNonQuery();
        sqlconnection.Close();
        if(count==1)
        {

            Response.Write("Your password has been successfully updated");
        }
        else
        {
            Response.Write("Enter Valid Password");
        }
    }
}