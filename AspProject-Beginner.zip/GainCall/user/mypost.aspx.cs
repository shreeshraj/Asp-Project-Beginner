﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class user_mypost : System.Web.UI.Page
{
    SqlConnection sqlconnection;
    string connectionstring;
    protected void Page_Load(object sender, EventArgs e)
    {
        connectionstring = ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;
        sqlconnection = new SqlConnection(connectionstring);

        if (Session["UserSession"] == null)
        {

            Response.Redirect("..//login.aspx");
        }
        else
        {
            int session = int.Parse(Session["UserSession"].ToString());
            SqlDataAdapter dataadapter = new SqlDataAdapter("select * from ProductDetails where UserId='"+session+"'", sqlconnection);
        DataSet ds = new DataSet();
        dataadapter.Fill(ds);
        Repeater1.DataSource = ds;
        Repeater1.DataBind();
        }
    }
}