﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection sqlconnection;
    string connectionstring;
    protected void Page_Load(object sender, EventArgs e)
    {
        connectionstring = ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;

        sqlconnection = new SqlConnection(connectionstring);
        if (!IsPostBack)
        {
            
           
           
           
           // SqlDataAdapter comm = new SqlDataAdapter("Select  * from ProductDetails where Product_Type='Lost Product'", sqlconnection);
            SqlDataAdapter comm = new SqlDataAdapter("Select  * from ProductDetails where Product_Type='Found Product'", sqlconnection);
            DataSet ds = new DataSet();
           // DataSet ds1 = new DataSet();
            comm.Fill(ds);
           // Foundcomm.Fill(ds1);

            Repeater1.DataSource = ds;
            Repeater1.DataBind();


           
        }

    }
    protected void btnpost_Click(object sender, EventArgs e)
    {
        Response.Redirect("../PostProduct/PostProduct.aspx");
    }
}