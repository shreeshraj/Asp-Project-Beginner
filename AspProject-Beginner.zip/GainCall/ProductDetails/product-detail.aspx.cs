﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class Default2 : System.Web.UI.Page
{
    string connectionstring = ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;
    SqlConnection sqlconnection;
    protected void Page_Load(object sender, EventArgs e)
    {
        sqlconnection = new SqlConnection(connectionstring);
     string  iddata= Request.QueryString["id"];
     SqlDataAdapter Foundcomm = new SqlDataAdapter("Select  * from ProductDetails where Product_Id='"+iddata+"'", sqlconnection);
     sqlconnection.Open();
     DataSet DS = new DataSet();
     Foundcomm.Fill(DS);


     Repeater2.DataSource = DS;
     Repeater2.DataBind();
    }
    protected void btnpost_Click(object sender, EventArgs e)
    {
        Response.Redirect("PostProduct.aspx");
    }
}