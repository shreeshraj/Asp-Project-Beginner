﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class lost_product_details : System.Web.UI.Page
{
    SqlConnection sqlconnection;
    string connectionstring;
    protected void Page_Load(object sender, EventArgs e)
    {
        connectionstring = ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;
        sqlconnection = new SqlConnection(connectionstring);
        DataSet ds = new DataSet();
        string state = Request.QueryString["State"];
        string city = Request.QueryString["City"];
        string producttype = Request.QueryString["ProductType"];
        string search = Request.QueryString["Searchproduct"];
        if (state != null || city != null || producttype != null || search != null)
        {
            
            SqlDataAdapter comm = new SqlDataAdapter("sp_SearchItem", sqlconnection);
            comm.SelectCommand.CommandType = CommandType.StoredProcedure;
            comm.SelectCommand.Parameters.AddWithValue("@state", state);
            comm.SelectCommand.Parameters.AddWithValue("@city", city);
            comm.SelectCommand.Parameters.AddWithValue("@producttype", producttype);
            comm.SelectCommand.Parameters.AddWithValue("@search", search);
           
            comm.Fill(ds);
            Repeater1.DataSource = ds;
            Repeater1.DataBind();
        }
        else
        {
            SqlDataAdapter dataadapter = new SqlDataAdapter("select * from ProductDetails ", sqlconnection);
            dataadapter.Fill(ds);
            Repeater1.DataSource = ds;
            Repeater1.DataBind();

        }

    }
    protected void btnpost_Click(object sender, EventArgs e)
    {
        Response.Redirect("../PostProduct/PostProduct.aspx");
    }
}