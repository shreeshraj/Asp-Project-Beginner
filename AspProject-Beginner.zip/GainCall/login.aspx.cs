﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class login : System.Web.UI.Page
{
    SqlConnection sqlconnection;
   
    string connection = ConfigurationManager.ConnectionStrings["GAINCALL"].ConnectionString;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
        sqlconnection = new SqlConnection(connection); 


    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {

        SqlCommand sqlcommand = new SqlCommand("sp_UserLogin", sqlconnection);
        sqlcommand.CommandType = CommandType.StoredProcedure;
        sqlcommand.Parameters.AddWithValue("@Email", txtemail.Text);
        sqlcommand.Parameters.AddWithValue("@Password", txtpassword.Text);
        sqlconnection.Open();
        SqlDataReader dataReader=  sqlcommand.ExecuteReader();
        while (dataReader.Read())
       {
            Session["UserSession"] = dataReader[0].ToString();
            Session["FirstName"] =   dataReader[1].ToString();
            Master.FindControl("myDiv").Visible = true;
            Response.Redirect("Index.aspx");


       }
        sqlconnection.Close();
       
        
       
    }
}